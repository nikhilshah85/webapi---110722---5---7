﻿namespace ProductsAPI
{
    public class ProductDetails
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public string pCategory { get; set; }
        public double pPrice { get; set; }
        public int pAvailableQty { get; set; }
        public bool pIsInStock { get; set; }

        static List<ProductDetails> pList = new List<ProductDetails>()
        {
            new ProductDetails(){ pId=101, pName="Pepsi", pCategory="Cold-Drink", pPrice=50, pAvailableQty=200, pIsInStock=true},
            new ProductDetails(){ pId=102, pName="Iphone", pCategory="Electronic", pPrice=50, pAvailableQty=200, pIsInStock=true},
            new ProductDetails(){ pId=103, pName="Maggie", pCategory="Fast-food", pPrice=50, pAvailableQty=200, pIsInStock=true},
            new ProductDetails(){ pId=104, pName="Cold Coffee", pCategory="Cold-Drink", pPrice=50, pAvailableQty=200, pIsInStock=true},
            new ProductDetails(){ pId=105, pName="Sandwitch", pCategory="Fast-food", pPrice=50, pAvailableQty=200, pIsInStock=true},
        };

        public List<ProductDetails> GetProductDetailsList()
        {
            return pList;
        }

        public ProductDetails GetProductById(int id)
        {
            var p = pList.Find(pr => pr.pId == id);
            if (p != null)
            {
                return p;
            }
            throw new Exception("Product Not Found");
        }
    }
}
