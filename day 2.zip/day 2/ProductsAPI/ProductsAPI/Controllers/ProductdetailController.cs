﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProductsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductdetailController : ControllerBase
    {
        ProductDetails pObj = new ProductDetails();

        [HttpGet]
        [Route("plist")]
        public IActionResult GetProducts()
        {
            return Ok(pObj.GetProductDetailsList());
        }

        [HttpGet]
        [Route("plist/{id}")]
        public IActionResult GetProductById(int id)
        {
            try
            {
                return Ok(pObj.GetProductById(id));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);   
            }
        }
    }
}
