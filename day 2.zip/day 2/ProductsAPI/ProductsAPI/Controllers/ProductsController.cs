﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProductsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        static List<string> productList = new List<string>()
        {
            "Pepsi","Maggie","Iphone","Air Pods"
        };    
              
        [HttpGet]
        [Route("plist")]
        public IActionResult Getproductslist()
        {
            return Ok(productList);
        }
        [HttpGet]
        [Route("plist/{id}")]
        public IActionResult GetProductById(int id)
        {
            if (id < 0)
            {
                return BadRequest("Please enter a positive value"); //status code 400
            }

            if (productList.Count > id)
            {
                return Ok(productList[id]); //statud code 200
            }
            return NotFound("No Product found at this position");  //status code 404
        }

        [HttpPost]
        [Route("plist/add/{newProductName}")]
        public IActionResult AddProduct(string newProductName)
        {
            productList.Add(newProductName);
            return Created("", "Product Added to list");
        }

        [HttpPut]
        [Route("plist/edit/{position}/{newValue}")]
        public IActionResult EditProduct(int position, string newValue)
        {
            if (productList.Count > position)
            {
                productList[position] = newValue;
                return Ok("Product updated");
            }            
             return NotFound("Sorry wrong index");
        }


        [HttpDelete]
        [Route("plist/{position}")]
        public IActionResult DeleteProduct(int position)
        {
            productList.Remove(productList[position]);
            return Accepted("Product removed successfully");
        }
    

    }
}
