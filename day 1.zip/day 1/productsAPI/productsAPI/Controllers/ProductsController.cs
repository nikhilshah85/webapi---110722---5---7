﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace productsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {


      

        [HttpGet]
        [Route("greet")]
        public IActionResult Greetings()
        {
            return Ok("Welcome to Web API Development");
            //u will return HTTP standards, 
        }

        public string SayHello()
        {
            return "Welcome to another method";
        }

        [HttpGet]
        [Route("greet/{guestName}")]
        public IActionResult Greetings(string guestName)
        {
            return Ok("Welcome to web API " + guestName);
        }

        [HttpGet]
        [Route("add/{num1}/{num2}")]
        public IActionResult Add(int num1, int num2)
        {
            return Ok(num1 + num2);
        }

    }
}
